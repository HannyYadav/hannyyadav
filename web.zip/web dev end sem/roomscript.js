document.addEventListener("DOMContentLoaded", () => {
    const roomsData = [
        {
            name: "Deluxe Room",
            img: "https://precisioncncturnedparts.com/wp-content/uploads/2023/10/heritage-hotel-rooms-and-suites-interior-img-5.jpg",
            description: "1.6 M² space, Free wifi, Air conditioner, Queen size bed, Free breakfast",
            category: "Deluxe"
        },
        {
            name: "Super Deluxe Room",
            img: "https://cdn11.bigcommerce.com/s-1qtb4u2pbj/images/stencil/original/image-manager/maineone222.jpg",
            description: "20 M² space, Free wifi, Air conditioner, King size bed, Free breakfast",
            category: "Deluxe"
        },
        {
            name: "Executive Suite",
            img: "https://fineacers.com/wp-content/uploads/2021/04/heritage-hotel-rooms-and-suites-interior-img-2.jpg",
            description: "20 M² space, Free wifi, Air conditioner, King size bed, Free breakfast",
            category: "Executive"
        },
        {
            name: "Deluxe Executive Room",
            img: "https://static.asianpaints.com/content/dam/asian_paints/blog/bhs/bhs-article6-a-fusion-of-the-modern-and-traditional-asian-paints.jpg",
            description: "24 M² space, Free wifi, Air conditioner, King size bed, Free breakfast",
            category: "Executive"
        },
        {
            name: "Royal Suite",
            img: "https://precisioncncturnedparts.com/wp-content/uploads/2023/10/heritage-hotel-rooms-and-suites-interior-img-4.jpg",
            description: "32 M² space, Free wifi, Air conditioner, King size bed, Free breakfast",
            category: "Suite"
        },
        {
            name: "Heritage Suite",
            img: "https://www.shutterstock.com/image-photo/loiretcher-france-june-14-2018-260nw-1163593477.jpg",
            description: "36 M² space, Free wifi, Air conditioner, King size bed, Free breakfast",
            category: "Suite"
        }
    ];

    const roomsContainer = document.getElementById("rooms-container");
    const roomFilter = document.getElementById("roomFilter");

    function renderRooms(filteredRooms) {
        roomsContainer.innerHTML = ""; // Clear previous content
        filteredRooms.forEach(room => {
            const roomDiv = document.createElement("div");
            roomDiv.className = "room";
            roomDiv.innerHTML = `
                <img src="${room.img}" alt="${room.name}">
                <h3>${room.name}</h3>
                <p>${room.description}</p>
                <a href="#" class="btn">Book Now</a>
            `;
            roomDiv.querySelector(".btn").addEventListener("click", () => {
                alert(You have selected ${room.name}!);
            });
            roomsContainer.appendChild(roomDiv);
        });
    }

    // Initial render
    renderRooms(roomsData);

    // Filter functionality
    roomFilter.addEventListener("change", (e) => {
        const selectedCategory = e.target.value;
        if (selectedCategory === "all") {
            renderRooms(roomsData);
        } else {
            const filteredRooms = roomsData.filter(room =>
                room.category.includes(selectedCategory)
            );
            renderRooms(filteredRooms);
        }
    });
});
// Fetch images data from JSON file
fetch('history.json')
    .then(response => response.json())
    .then(data => {
        loadImages(data);
    })
    .catch(error => console.error('Error loading images:', error));

function loadImages(imagesData) {
    const imagesSection = document.getElementById("images-section");
    let row = document.createElement("div");
    row.classList.add("image-row");

    imagesData.forEach((image, index) => {
        if (index > 0 && index % 3 === 0) {
            imagesSection.appendChild(row);
            row = document.createElement("div");
            row.classList.add("image-row");
        }
        // if (image.src === "https://websitedemos.net/heritage-hotel-04/wp-content/uploads/sites/815/2021/04/heritage-hotel-about-story-img-2.jpg",) {  // Example condition to block empty image sources
        //     console.log("Blocked image with empty src");
        //     return;  // Skip this iteration and do not append the image
        // }
    

        const img = document.createElement("img");
        img.src = image.src;
        img.alt = image.alt;
        row.appendChild(img);
    });

    imagesSection.appendChild(row);
}

// Toggle dark mode
const darkModeToggle = document.getElementById("dark-mode-toggle");
darkModeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
});

// Zoom in/out functionality
function toggleZoom(event) {
    const img = event.target;
    img.classList.toggle("zoomed");
}

// Hover effect on images
document.addEventListener("mouseover", (event) => {
    if (event.target.tagName === "IMG" && event.target.classList.contains("zoomable")) {
        event.target.style.transform = "scale(1.1)";
        event.target.style.transition = "transform 0.3s";
    }
});

document.addEventListener("mouseout", (event) => {
    if (event.target.tagName === "IMG" && event.target.classList.contains("zoomable")) {
        event.target.style.transform = "scale(1)";
    }
});

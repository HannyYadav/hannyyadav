// // Fetch and display dining data
// document.addEventListener("DOMContentLoaded", () => {
//     fetch("dining.json")
//         .then(response => response.json())
//         .then(data => {
//             const diningSection = document.querySelector(".dining-section");
//             data.diningOptions.forEach(option => {
//                 const diningItem = document.createElement("div");
//                 diningItem.classList.add("dining-item");
                
//                 diningItem.innerHTML = `
//                     <img src="${option.image}" alt="${option.name}">
//                     <h3>${option.name}</h3>
//                     <p>${option.description}</p>
//                 `;
                
//                 diningSection.appendChild(diningItem);
//             });
//         })
//         .catch(error => console.error("Error loading dining data:", error));
// });


// Fetch and display dining data
document.addEventListener("DOMContentLoaded", () => {
    let diningOptions = []; // Store dining data globally for sorting/filtering

    fetch("dining.json")
        .then(response => response.json())
        .then(data => {
            diningOptions = data.diningOptions; // Save data globally
            displayDiningOptions(diningOptions); // Display all options initially
        })
        .catch(error => console.error("Error loading dining data:", error));

    // Display dining options
    function displayDiningOptions(options) {
        const diningSection = document.querySelector(".dining-section");
        diningSection.innerHTML = ""; // Clear the section before re-rendering
        options.forEach(option => {
            const diningItem = document.createElement("div");
            diningItem.classList.add("dining-item");
            diningItem.innerHTML = `
                <img src="${option.image}" alt="${option.name}">
                <h3>${option.name}</h3>
                <p>${option.description}</p>
            `;
            diningSection.appendChild(diningItem);
        });
    }

    // Sort dining options alphabetically by name
    document.querySelector("#sort-alpha").addEventListener("click", () => {
        const sortedOptions = [...diningOptions].sort((a, b) =>
            a.name.localeCompare(b.name)
        );
        displayDiningOptions(sortedOptions);
    });

    // Sort dining options by description length
    document.querySelector("#sort-desc-length").addEventListener("click", () => {
        const sortedOptions = [...diningOptions].sort((a, b) =>
            a.description.length - b.description.length
        );
        displayDiningOptions(sortedOptions);
    });

    // Search dining options by name
    document.querySelector("#search-bar").addEventListener("input", (event) => {
        const query = event.target.value.toLowerCase();
        const filteredOptions = diningOptions.filter(option =>
            option.name.toLowerCase().includes(query)
        );
        displayDiningOptions(filteredOptions);
    });

    // Filter dining options by keyword in description
    document.querySelector("#filter-keyword").addEventListener("input", (event) => {
        const keyword = event.target.value.toLowerCase();
        const filteredOptions = diningOptions.filter(option =>
            option.description.toLowerCase().includes(keyword)
        );
        displayDiningOptions(filteredOptions);
    });
});


document.addEventListener("DOMContentLoaded", () => {
    fetch("gallery.json")
        .then(response => response.json())
        .then(data => {
            const galleryGrid = document.querySelector(".gallery-grid");
            data.images.forEach(image => {
                const galleryItem = document.createElement("div");
                galleryItem.classList.add("gallery-item");

                const img = document.createElement("img");
                img.src = image.src;
                img.alt = image.alt;

                galleryItem.appendChild(img);
                galleryGrid.appendChild(galleryItem);
            });
        })
        .catch(error => console.error("Error loading gallery data:", error));
});

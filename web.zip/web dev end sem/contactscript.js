document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const contactData = {
        name: document.getElementById("name").value,
        lastName: document.getElementById("last").value,
        email: document.getElementById("email").value,
        phone: document.getElementById("phone").value,
        message: document.getElementById("message").value
    };

    console.log("Contact Form Data:", contactData);
    alert("Thank you! Your message has been sent.");
});
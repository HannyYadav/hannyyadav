const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

// Initialize the app
const app = express();

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/hotelBooking', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('Connected to MongoDB');
}).catch(err => {
    console.error('Database connection error:', err);
});

// Define a schema
const bookingSchema = new mongoose.Schema({
    name: String,
    email: String,
    phone: String,
    guests: Number,
    roomType: String
});

// Create a model
const Booking = mongoose.model('Booking', bookingSchema);

// Handle POST request to save booking
app.post('/api/bookings', async (req, res) => {
    try {
        const booking = new Booking(req.body);
        await booking.save();
        res.status(201).send({ message: 'Booking saved successfully!' });
    } catch (err) {
        res.status(500).send({ error: 'Failed to save booking' });
    }
});

// Start the server
const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

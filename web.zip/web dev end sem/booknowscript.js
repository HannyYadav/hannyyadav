document.getElementById("bookingForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const bookingDetails = {
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        phone: document.getElementById("phone").value,
        guests: document.getElementById("guests").value,
        roomType: document.getElementById("roomType").value
    };

    console.log("Booking Details:", bookingDetails);
    alert("Thank you, your booking has been received!");

    // Clear the form
    document.getElementById("bookingForm").reset();
});
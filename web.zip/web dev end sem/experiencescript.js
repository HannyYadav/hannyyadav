// Fetch experience data from JSON file and dynamically add to the page
fetch('experience.json')
    .then(response => response.json())
    .then(data => {
        const experienceContainer = document.getElementById('experience-container');
        
        data.forEach(experience => {
            const experienceBlock = document.createElement('div');
            experienceBlock.classList.add('experience-block');
            
            const img = document.createElement('img');
            img.src = experience.image;
            img.alt = experience.title;
            img.classList.add('experience-img');
            
            const textDiv = document.createElement('div');
            textDiv.classList.add('experience-text');
            
            const title = document.createElement('h2');
            title.textContent = experience.title;
            
            const description = document.createElement('p');
            description.textContent = experience.description;
            
            textDiv.appendChild(title);
            textDiv.appendChild(description);
            experienceBlock.appendChild(img);
            experienceBlock.appendChild(textDiv);
            experienceContainer.appendChild(experienceBlock);
        });
    })
    .catch(error => console.error('Error loading experience data:', error));
